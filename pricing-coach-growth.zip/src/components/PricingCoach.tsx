import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

type Question = {
  id: string;
  text: string;
  options: { value: string; label: string }[];
};

const questions: Question[] = [
  {
    id: 'lastRaise',
    text: 'When was the last time you raised your prices?',
    options: [
      { value: 'never', label: '❌ Never' },
      { value: 'over2years', label: '⏰ Over 2 years ago' },
      { value: '1-2years', label: '📅 1-2 years ago' },
      { value: 'thisyear', label: '✅ This year' }
    ]
  },
  {
    id: 'tieredPricing',
    text: 'Do you offer tiered pricing (basic, pro, premium)?',
    options: [
      { value: 'no', label: '❌ No, just one price' },
      { value: 'yes', label: '✅ Yes, multiple tiers' }
    ]
  },
  {
    id: 'subscription',
    text: 'Do you offer subscription or recurring services?',
    options: [
      { value: 'no', label: '❌ No, one-time payments only' },
      { value: 'yes', label: '✅ Yes, recurring revenue' }
    ]
  },
  {
    id: 'demand',
    text: 'How strong is your customer demand right now?',
    options: [
      { value: 'low', label: '📉 Low - struggling to find customers' },
      { value: 'moderate', label: '📊 Moderate - steady flow' },
      { value: 'high', label: '🔥 High - more demand than capacity' }
    ]
  },
  {
    id: 'competitors',
    text: 'Are competitors charging more than you?',
    options: [
      { value: 'yes', label: '💰 Yes, significantly more' },
      { value: 'similar', label: '⚖️ Similar pricing' },
      { value: 'no', label: '🏆 No, I charge more' }
    ]
  }
];

const PricingCoach: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<'welcome' | 'questions' | 'results' | 'leadCapture'>('welcome');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [email, setEmail] = useState('');

  const handleAnswer = (questionId: string, answer: string) => {
    const newAnswers = { ...answers, [questionId]: answer };
    setAnswers(newAnswers);
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setCurrentStep('results');
    }
  };

  const generateStrategy = () => {
    let strategy = [];
    
    if (answers.lastRaise === 'never' || answers.lastRaise === 'over2years' || answers.lastRaise === '1-2years') {
      strategy.push('🚀 You haven\'t raised prices in over a year. Inflation alone justifies a 5-8% increase.');
    }
    
    if (answers.tieredPricing === 'no') {
      strategy.push('💎 Add a Pro tier with more value for 2-3X pricing flexibility.');
    }
    
    if (answers.subscription === 'no') {
      strategy.push('💰 Introduce monthly plans for predictable recurring income.');
    }
    
    if (answers.demand === 'high') {
      strategy.push('⚡ High demand = perfect time for premium pricing. Raise prices 10-15%.');
    }
    
    if (answers.competitors === 'yes') {
      strategy.push('🎯 Competitors charge more? You\'re leaving money on the table. Match or beat their pricing.');
    }
    
    return strategy.length > 0 ? strategy : ['✨ Your pricing looks solid! Focus on value communication and upselling.'];
  };

  if (currentStep === 'welcome') {
    return (
      <Card className="max-w-2xl mx-auto shadow-2xl border-0 bg-gradient-to-br from-white to-blue-50">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mb-4">
            <span className="text-2xl">💰</span>
          </div>
          <CardTitle className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Pricing Strategy Coach
          </CardTitle>
          <Badge variant="secondary" className="mx-auto mt-2">2025 Revenue Growth</Badge>
        </CardHeader>
        <CardContent className="text-center space-y-6 px-8 pb-8">
          <p className="text-xl font-semibold text-gray-700">
            Hey there 👋 Ready to see if it's time to raise your prices—and how to do it the smart way?
          </p>
          <p className="text-lg text-gray-600">
            Let me ask a few quick questions to give you a personalized pricing strategy.
          </p>
          <Button 
            onClick={() => setCurrentStep('questions')} 
            size="lg" 
            className="w-full max-w-md h-14 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg transform hover:scale-105 transition-all"
          >
            Let's Get Started 🚀
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (currentStep === 'questions') {
    const question = questions[currentQuestion];
    return (
      <Card className="max-w-2xl mx-auto shadow-2xl border-0 bg-gradient-to-br from-white to-blue-50">
        <CardHeader className="pb-4">
          <div className="flex justify-between items-center mb-2">
            <CardTitle className="text-2xl font-bold text-gray-800">
              Question {currentQuestion + 1} of {questions.length}
            </CardTitle>
            <Badge variant="outline">{Math.round(((currentQuestion + 1) / questions.length) * 100)}%</Badge>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 shadow-inner">
            <div 
              className="bg-gradient-to-r from-blue-600 to-purple-600 h-3 rounded-full transition-all duration-500 shadow-sm" 
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-6 px-8 pb-8">
          <h3 className="text-xl font-bold text-gray-800">{question.text}</h3>
          <div className="space-y-3">
            {question.options.map((option) => (
              <Button
                key={option.value}
                variant="outline"
                className="w-full text-left justify-start h-auto p-6 text-lg border-2 hover:border-blue-400 hover:bg-blue-50 transition-all transform hover:scale-105 shadow-sm"
                onClick={() => handleAnswer(question.id, option.value)}
              >
                {option.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (currentStep === 'results') {
    const strategy = generateStrategy();
    return (
      <Card className="max-w-2xl mx-auto shadow-2xl border-0 bg-gradient-to-br from-white to-green-50">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center mb-4">
            <span className="text-2xl">🎯</span>
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
            Your Custom Pricing Strategy
          </CardTitle>
          <Badge variant="secondary" className="mx-auto mt-2">Personalized for You</Badge>
        </CardHeader>
        <CardContent className="space-y-6 px-8 pb-8">
          <div className="space-y-4">
            {strategy.map((point, index) => (
              <div key={index} className="p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl border-l-4 border-green-500 shadow-sm">
                <p className="font-semibold text-gray-800 text-lg">{point}</p>
              </div>
            ))}
          </div>
          <div className="text-center space-y-4 pt-4">
            <p className="text-xl font-bold text-gray-800">Want this strategy emailed to you?</p>
            <Button 
              onClick={() => setCurrentStep('leadCapture')} 
              size="lg"
              className="w-full max-w-md h-14 text-lg font-semibold bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 shadow-lg transform hover:scale-105 transition-all"
            >
              Get My Strategy PDF 📧
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (currentStep === 'leadCapture') {
    return (
      <Card className="max-w-2xl mx-auto shadow-2xl border-0 bg-gradient-to-br from-white to-purple-50">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mb-4">
            <span className="text-2xl">📧</span>
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Get Your Strategy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 px-8 pb-8">
          <p className="text-center text-lg text-gray-600">
            Enter your email to receive your personalized pricing strategy and bonus resources.
          </p>
          <div className="space-y-4">
            <Input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="text-center h-14 text-lg border-2 focus:border-purple-400 shadow-sm"
            />
            <Button 
              className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg transform hover:scale-105 transition-all" 
              onClick={() => {
                alert(`Strategy sent to ${email}! Check your inbox.`);
                setCurrentStep('welcome');
                setCurrentQuestion(0);
                setAnswers({});
                setEmail('');
              }}
            >
              Send My Strategy 🚀
            </Button>
          </div>
          <p className="text-sm text-center text-gray-500">
            No spam, just value. Unsubscribe anytime.
          </p>
        </CardContent>
      </Card>
    );
  }

  return null;
};

export default PricingCoach;